import { Component } from '@angular/core';
import { TechInfoContentComponent } from '../tech-info-content/tech-info-content.component';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tech-info-list',
  standalone: true,
  imports: [TechInfoContentComponent, CommonModule],
  templateUrl: './tech-info-list.component.html',
  styleUrl: './tech-info-list.component.scss'
})

export class TechInfoListComponent {
  constructor(
    private router: Router,
    private route: ActivatedRoute
  ) { }

  selectedTab: string = 'lock'; // Default tab
  activeTab: number = 1;
  tech_info_id: any = null; // Defined to allow hint note visibility
  // isWizard: boolean = false;

  ngOnInit() {
    // this.isWizard = !this.router.url.includes('tech-info-list');
  }

  toggleSwitch(element: any) {
    element.classList.toggle("active");
  }

  selectTab(tab: string) {
    this.selectedTab = tab;
  }

  firstTabCount() {
    this.activeTab = 1;
  }

  secondTabCount() {
    this.activeTab = 2;
  }

  thirdTabCount() {
    this.activeTab = 3;
  }

  nextTabInfo() {
    switch (this.activeTab) {
      case 1:
        this.selectTab('pos');
        this.secondTabCount();
        break;
      case 2:
        this.selectTab('other');
        this.thirdTabCount();
        break;
    }
  }
  nextTab() {
    let nextTab = document.getElementById('services-tab');
    if (nextTab) {
      (nextTab as HTMLAnchorElement).click();
    }
  }

  previousTab() {
    switch (this.activeTab) {
      case 1:
        let nextTab = document.getElementById('property-tab');
        if (nextTab) {
          (nextTab as HTMLAnchorElement).click();
        }
        break;
      case 2:
        this.selectTab('lock');
        this.firstTabCount();
        break;
      case 3:
        this.selectTab('pos');
        this.secondTabCount();
    }

  }
  addTechnicalInfo() {
    this.router.navigate(['/add-technical-info'])
  }

}
